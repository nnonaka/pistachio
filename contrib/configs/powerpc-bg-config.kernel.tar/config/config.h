/* Automatically generated, don't edit */
/* Generated on: froschkoenig */
/* At: Wed, 02 Jun 2010 02:28:55 +0000 */
/* Linux version 2.6.32-3-686 (Debian 2.6.32-9) (maks@debian.org) (gcc version 4.3.4 (Debian 4.3.4-8) ) #1 SMP Thu Feb 25 06:14:20 UTC 2010 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_X86
#define CONFIG_ARCH_POWERPC 1
#undef  CONFIG_ARCH_POWERPC64


/* Processor Type */
#define CONFIG_CPU_POWERPC_PPC440 1
#undef  CONFIG_CPU_POWERPC_IBM750
#undef  CONFIG_CPU_POWERPC_PPC604


/* Platform */
#undef  CONFIG_PLAT_OFPPC
#define CONFIG_PLAT_PPC44X 1


/* Sub-Platform */
#define CONFIG_SUBPLAT_440_BGP 1


/* Miscellaneous */

#undef  CONFIG_SMP
#define CONFIG_SMP_MAX_PROCS 4


/* Kernel */
#define CONFIG_EXPERIMENTAL 1

/* Experimental Features */
#define CONFIG_X_PAGER_EXREGS 1
#define CONFIG_X_CTRLXFER_MSG 1
#define CONFIG_X_PPC_SOFTHVM 1

/* Kernel scheduling policy */
#define CONFIG_SCHED_RR 1
#undef  CONFIG_X_SCHED_HS


#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1
#define CONFIG_DEBUG_SYMBOLS 1
#undef  CONFIG_NEW_MDB
#define CONFIG_STATIC_TCBS 1


/* Debugger */
#define CONFIG_KDB 1

/* Consoles */
#undef  CONFIG_KDB_CONS_BGP_JTAG
#define CONFIG_KDB_CONS_BGP_TREE 1

#define CONFIG_KDB_DISAS 1
#undef  CONFIG_KDB_ON_STARTUP
#undef  CONFIG_KDB_BREAKIN
#undef  CONFIG_KDB_BREAKIN_BREAK
#undef  CONFIG_KDB_BREAKIN_ESCAPE
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#define CONFIG_VERBOSE_INIT 1
#define CONFIG_TRACEPOINTS 1
#undef  CONFIG_KMEM_TRACE



/* Code Generator Options */
#define CONFIG_SYSV_ABI 1
#define CONFIG_PPC_MULTIWORD_INSTR 1


/* Derived symbols */
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_X86_PSE
#define CONFIG_BIGENDIAN 1
#define CONFIG_PPC_MMU_TLB 1
#undef  CONFIG_X86_SYSENTER
#undef  CONFIG_X86_PGE
#undef  CONFIG_X86_FXSR
#define CONFIG_IS_32BIT 1
#undef  CONFIG_X86_HTT
#undef  CONFIG_X86_PAT
#define CONFIG_PPC_BOOKE 1
#undef  CONFIG_IS_64BIT
#undef  CONFIG_MULTI_ARCHITECTURE
#undef  CONFIG_X86_EM64T
#define CONFIG_PPC_CACHE_L1_WRITETHROUGH 1
#define CONFIG_PPC_TLB_INV_LOCAL 1
#define CONFIG_PPC_CACHE_ICBI_LOCAL 1
#undef  CONFIG_X86_SMALL_SPACES_GLOBAL
#undef  CONFIG_X86_HVM
#undef  CONFIG_PPC_MMU_SEGMENTS
#undef  CONFIG_X86_TSC
/* That's all, folks! */
#define AUTOCONF_INCLUDED
